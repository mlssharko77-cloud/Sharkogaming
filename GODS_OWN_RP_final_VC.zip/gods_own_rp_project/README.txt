GODS OWN RP — FULL PROJECT
==========================

An original, browser-based 3D roleplay prototype inspired by Kerala village life. It uses Three.js from a CDN and custom procedural shapes, so an internet connection is needed when loading the game.

INCLUDED FEATURES
- Expanded original Kerala-inspired open world with city blocks, west highway, countryside farms, hills, house clusters, backwater coast and distant districts
- Original player avatar, fashion shop, saved outfits and cash (local device save)
- Auto-rickshaw driving and a boat landmark
- Tea shop, fishing, village patrol, newspaper delivery, bus conductor, barber assistant and football-ground jobs
- Free bicycle that can be ridden; newspaper route goes from the newspaper shop to three homes
- Local market purchases, house rental and furniture purchase (saved locally)
- Day/night cycle, clear/rainy weather toggle, minimap
- Mobile joystick, camera swipe (swipe rotates angle; camera mode stays unchanged), jump/action buttons, compact all-in-one menu, music volume and fullscreen toggle
- Public multiplayer server for up to 50 concurrent players in one shared world, with text chat and online direct messages when hosted using this server
- A physical Friends Lounge house exists on the map; real voice calling is not enabled in this build
- Original generated instrumental background music in assets/gods-own-rp-adventure.mp3

RUN LOCALLY
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000

DEPLOY
- Netlify can host the static website/game files (index.html, game.html, assets). Extract the ZIP first and deploy the project folder.
- Netlify static hosting does not run server.js, so multiplayer rooms and direct messages require deploying the Node server separately to a WebSocket-capable host. Voice calling is not enabled in this build.
- Use `npm install` as build command and `npm start` as start command.
- `render.yaml` is included as a starting point for Render.
- Multiplayer only works after the Node server is deployed. The game uses one public room, so players join the same world automatically; capacity is capped at 50 concurrent players. Deploy the server (for example, on Render), then open the Netlify site with `?server=https://YOUR-SERVER.onrender.com` so the embedded game connects to the Node server. Replace the example URL with the real deployed server URL.

NOTES / LIMITATIONS
- This is a playable prototype, not a finished commercial-scale Roblox-sized game.
- The game is not a 20 MB download target guaranteed; the full project includes about 3 MB of music plus code. Three.js is loaded from a CDN.
- Proximity voice chat (WebRTC, uses the game server for signalling) works when the Node server is running: join the room, tap Voice, allow the microphone, and walk near other players. It uses free STUN servers only; a few strict networks may need a TURN server.
- The background music was synthesized for this project. Independent legal clearance cannot be guaranteed, so check any distribution/platform requirements before public release.
- Multiplayer positions and chat are prototype-level; the public room has a 50-player cap but this is not a high-scale production server. There are no real accounts, moderation dashboard, anti-cheat, persistent cloud inventory, or authenticated admin permissions.
