const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, maxHttpBufferSize: 1e5 });
const PORT = process.env.PORT || 3000;
const MAX_PLAYERS_PER_SERVER = 50;
const PUBLIC_ROOM = 'public';
app.use(express.json({ limit: '20kb' }));
app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'GODS OWN RP', mode: 'public', maxPlayers: MAX_PLAYERS_PER_SERVER }));
app.get('/api/status', (_req, res) => {
  const players = roomPlayers(PUBLIC_ROOM);
  res.json({ game: 'GODS OWN RP', server: 'public', online: players.size, maxPlayers: MAX_PLAYERS_PER_SERVER, full: players.size >= MAX_PLAYERS_PER_SERVER });
});
app.post('/api/voice-token', (_req, res) => res.status(503).json({ error: 'Voice chat is optional and needs LiveKit credentials configured by the server owner.' }));

const rooms = new Map();
const clean = (value, max = 24) => String(value ?? '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, max);
function roomPlayers(room) { return rooms.get(room) || new Map(); }
function count(room) { return roomPlayers(room).size; }
function publicPlayer(p) { return { id: p.id, name: p.name, x: p.x || 0, y: p.y || 0, z: p.z || 0, rotation: p.rotation || 0, inVehicle: !!p.inVehicle }; }

io.on('connection', socket => {
  let currentRoom = null;
  let player = { id: socket.id, name: 'Player', x: 0, y: 0, z: 0, rotation: 0 };
  socket.on('room:join', data => {
    const name = clean(data?.name, 20) || 'Player';
    // One public world for everyone; clients cannot create extra rooms to bypass the cap.
    const room = PUBLIC_ROOM;
    const members = roomPlayers(room);
    if (currentRoom === room && members.has(socket.id)) {
      player.name = name;
      socket.emit('room:joined', { room, count: members.size, maxPlayers: MAX_PLAYERS_PER_SERVER, players: [...members.values()].filter(p => p.id !== socket.id).map(publicPlayer) });
      return;
    }
    if (members.size >= MAX_PLAYERS_PER_SERVER) {
      socket.emit('room:error', { message: 'The public server is full (50/50). Please try again later.' });
      return;
    }
    if (currentRoom) {
      const oldRoom = currentRoom;
      socket.leave(oldRoom);
      roomPlayers(oldRoom).delete(socket.id);
      socket.to(oldRoom).emit('player:left', { id: socket.id, name: player.name, count: count(oldRoom) });
      io.to(oldRoom).emit('room:count', { count: count(oldRoom), maxPlayers: MAX_PLAYERS_PER_SERVER });
    }
    if (!rooms.has(room)) rooms.set(room, new Map());
    currentRoom = room; player.name = name;
    members.set(socket.id, player); socket.join(room);
    socket.emit('room:joined', { room, count: members.size, maxPlayers: MAX_PLAYERS_PER_SERVER, players: [...members.values()].filter(p => p.id !== socket.id).map(publicPlayer) });
    socket.to(room).emit('player:joined', { ...publicPlayer(player), count: members.size, maxPlayers: MAX_PLAYERS_PER_SERVER });
    io.to(room).emit('room:count', { count: members.size, maxPlayers: MAX_PLAYERS_PER_SERVER });
  });
  socket.on('player:move', data => {
    if (!currentRoom) return;
    const x = Number(data?.x), y = Number(data?.y), z = Number(data?.z), rotation = Number(data?.rotation);
    if (![x,y,z,rotation].every(Number.isFinite)) return;
    player.x = Math.max(-420, Math.min(420, x)); player.y = Math.max(0, Math.min(3, y)); player.z = Math.max(-420, Math.min(420, z)); player.rotation = rotation; player.inVehicle = !!data.inVehicle;
    socket.to(currentRoom).volatile.emit('player:move', publicPlayer(player));
  });
  let lastChat = 0;
  socket.on('chat:send', data => {
    if (!currentRoom) return;
    const now = Date.now(); if (now - lastChat < 650) return; lastChat = now;
    const message = clean(data?.message, 240); if (!message) return;
    io.to(currentRoom).emit('chat:message', { name: player.name, message, at: now });
  });
  socket.on('dm:send', data => {
    if (!currentRoom) return;
    const to = clean(data?.to, 20).toLowerCase();
    const message = clean(data?.message, 240);
    if (!to || !message) return;
    const recipient = [...roomPlayers(currentRoom).values()].find(p => p.name.toLowerCase() === to && p.id !== socket.id);
    if (!recipient) { socket.emit('dm:status', { message: 'Friend is not online in this room.' }); return; }
    io.to(recipient.id).emit('dm:message', { from: player.name, message, at: Date.now() });
    socket.emit('dm:status', { message: 'Private message delivered to ' + recipient.name + '.' });
  });
  socket.on('voice:signal', data => {
    if (!currentRoom) return;
    const to = clean(data?.to, 40);
    if (!to || to === socket.id || !roomPlayers(currentRoom).has(to)) return;
    io.to(to).emit('voice:signal', { from: socket.id, data: data.data });
  });
  socket.on('disconnect', () => {
    if (!currentRoom) return;
    const members = roomPlayers(currentRoom); members.delete(socket.id);
    socket.to(currentRoom).emit('player:left', { id: socket.id, name: player.name, count: members.size });
    io.to(currentRoom).emit('room:count', { count: members.size, maxPlayers: MAX_PLAYERS_PER_SERVER });
    if (!members.size) rooms.delete(currentRoom);
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`GODS OWN RP running on port ${PORT}`));
